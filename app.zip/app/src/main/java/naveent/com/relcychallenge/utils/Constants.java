package naveent.com.relcychallenge.utils;

/**
 * Created by NaveenT on 8/28/14.
 */
public class Constants {
    public static String GOOGLE_QUERY = "https://ajax.googleapis.com/ajax/services/search/images?";
    public static String API_VERSION = "v=1.0";
    public static String USER_IP = "userip=192.168.0.1";
    public static String RESULT_SIZE="rsz=8";

}
